def alter(x):
  x = 4
  return x
  
x = 3
alter(x)
print(x)
