
Funcionalidades

descrição:  funcionalidade (* 00/ 00) -> "A 'funcionalidade' foi feita no dia 00/00"

1 - criar carro (* 29/11)
2 - ler carros (* 29/11)
3 - editar dados de carro  (* 6/12)
4 - deletar um carro (* 6/12)
5 - pesquisar um carro (* 6/12)
6 - filtrar pesquisa por atributos + ordernar do menor/maior atributo
7 - alugar / desalugar um carro (* 29/11)

8 - criar usuario
9 - ler usuario
10 - editar dados de usuario
11 - remover usuario


funcionalidades extras:
adicionar persistencia de dados
tratamente de execções
confirmar ou cancelar ação de usuário (* 6/12)
inserir mecanismo de busca binária

